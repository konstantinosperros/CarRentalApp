import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-NRB5VDQW.js";
import "./chunk-Y62KYHCT.js";
import "./chunk-X6JV76XL.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
