import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-ABQCCJH7.js";
import "./chunk-VCNO2JJF.js";
import "./chunk-2E4SSK63.js";
import "./chunk-YPBLRZ4L.js";
import "./chunk-STKTRHOA.js";
import "./chunk-MV4GSUHJ.js";
import "./chunk-MJN7JAV6.js";
import "./chunk-KMETBW26.js";
import "./chunk-Y62KYHCT.js";
import "./chunk-X6JV76XL.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
