// import { NgModule } from "@angular/core";
// import { AppComponent } from "./app.component";
// import { LoginComponent } from "./auth/components/login/login.component";
// import { SignupComponent } from "./auth/components/signup/signup.component";
// import { BrowserModule } from "@angular/platform-browser";
// import { FormsModule, ReactiveFormsModule } from "@angular/forms";
// import { HttpClientModule } from "@angular/common/http";
// import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
// import { NZ_I18N, en_US } from "ng-zorro-antd/i18n";
// import bootstrap from "../main.server";
// import en from "@angular/common/locales/en";

// import { NzSpinModule } from 'ng-zorro-antd/spin';
// import { NzFormControlComponent, NzFormModule } from 'ng-zorro-antd/form';
// import { NzButtonModule } from 'ng-zorro-antd/button';
// import { NzInputModule} from 'ng-zorro-antd/input';
// import { NzLayoutModule} from 'ng-zorro-antd/layout';
// import { RouterOutlet } from "@angular/router";
// import { NzSelectModule } from "ng-zorro-antd/select/select.module";

// resisterLocaleData(en);

// @NgModule({
//     declarations: [
//          AppComponent,
//          LoginComponent,
//          SignupComponent
//     ],
//     imports: [
//    BrowserModule,
//     FormsModule,
//     HttpClientModule,
//     BrowserAnimationsModule,
//     ReactiveFormsModule,
    

//     RouterOutlet,
//     NzSpinModule,
//     NzFormModule,
//     NzButtonModule,
//     NzInputModule,
//     NzLayoutModule,
//     ReactiveFormsModule,
//     NzSelectModule,FormsModule],
//     providers: [
//     { provide: NZ_I18N, useValue: en_US }
//     ],
//     bootstrap: [AppComponent]
//     })
//     export class AppModule {}

// function resisterLocaleData(en: any) {
//     throw new Error("Function not implemented.");
// }
