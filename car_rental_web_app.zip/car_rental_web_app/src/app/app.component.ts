import { Component, NgModule } from '@angular/core';
import { Router, RouterModule, RouterOutlet, Routes } from '@angular/router';

import {  ReactiveFormsModule } from '@angular/forms';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzFormModule} from 'ng-zorro-antd/form';
import { NzButtonModule} from 'ng-zorro-antd/button';
import { NzInputModule} from 'ng-zorro-antd/input';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { StorageService } from './auth/services/storage/storage.service';

// import {getWindow} from "ssr-window";

// ngOnInit() {
// const width = getWindow().innerWidth;
// }

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,
          ReactiveFormsModule,
          NzSpinModule,
          NzFormModule,
          NzButtonModule,
          NzInputModule,
          NzLayoutModule,     
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'car_rental_web_app';

  isCustomerLoggedIn: boolean = StorageService.isCustomerdminLoggedIn();
  isAdminLoggedIn: boolean = StorageService.isAdminLoggedIn();

  constructor(private router: Router) {}

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event.constructor.name === "NavigationEnd") {
        this.isAdminLoggedIn = StorageService.isAdminLoggedIn();
        this.isCustomerLoggedIn = StorageService.isCustomerdminLoggedIn();
      }
    })
  }
  logout() {
    StorageService.logout();
    this.router.navigateByUrl("/login");
  }

}

function ngOnInit() {
  throw new Error('Function not implemented.');
}

